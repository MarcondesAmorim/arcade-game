frontend-nanodegree-arcade-game
===============================

## About:
The Game is a project for a Udacity course, Object Oriented Programming in javascript to be specific. It uses ES6 synthax and may not run in some browsers.


## How To Play:
You can play [here](https://cwaku.github.io/classic-arcade-game).
Player is required to cross over to river without colliding with enemies(bugs).
It currently uses the arrow keys as input. Touch input will be added soon.


## Dependencies:
All game resources and engine was provided by Udacity


## Contributing:
Contributions are not allowed untill further notice

# ENJOY THE GAME
To run the game locally, clone or download the zip file and run `index.html` in browser.
